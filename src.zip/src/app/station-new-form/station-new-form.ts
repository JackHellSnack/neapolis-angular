import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { StationService } from '../station-service';
import Station from '../station'; // Aggiusta il percorso in base alla tua struttura

@Component({
  selector: 'app-station-new-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './station-new-form.html',
  styleUrls: ['./station-new-form.css']
})
export class StationNewForm {
  
  private stationService = inject(StationService);

  // Oggetto di appoggio legato al form tramite ngModel
  station: Station = {
    id: 0,
    name: '',
    city: ''
  };

  successMessage: string = '';
  errorMessage: string = '';

  onSubmit(form: NgForm): void {
    if (form.invalid) {
      return;
    }

    this.stationService.save(this.station).subscribe({
      next: (savedStation) => {
        this.successMessage = `Stazione "${savedStation.name}" inserita con successo!`;
        this.errorMessage = '';
        this.resetForm(form);
      },
      error: (err) => {
        this.errorMessage = 'Errore durante l\'inserimento della stazione. Riprova.';
        this.successMessage = '';
        console.error(err);
      }
    });
  }

  resetForm(form: NgForm): void {
    form.resetForm();
    this.station = {
      id: 0,
      name: '',
      city: ''
    };
  }
}