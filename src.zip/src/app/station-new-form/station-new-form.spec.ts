import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StationNewForm } from './station-new-form';

describe('StationNewForm', () => {
  let component: StationNewForm;
  let fixture: ComponentFixture<StationNewForm>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [StationNewForm],
    }).compileComponents();

    fixture = TestBed.createComponent(StationNewForm);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
