import { Service } from '@angular/core';
import { inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import Ticket from './ticket'; // Importa l'interfaccia aggiornata
import TravelCard from './travelCard';

@Service()
export class TravelerCardService {

  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:8080/brianzatrains/api/travelercards';

  // --- READ ALL ---
  findAll(): Observable<TravelCard[]> {
    return this.http.get<TravelCard[]>(this.apiUrl);
  }

  // --- READ BY ID ---
  findById(id: number): Observable<TravelCard> {
    return this.http.get<TravelCard>(`${this.apiUrl}/${id}`);
  }

  // --- CREATE ---
  save(travelerCard: TravelCard): Observable<TravelCard> {
    return this.http.post<TravelCard>(this.apiUrl, travelerCard);
  }

  // --- UPDATE ---
  update(id: number, travelCard: TravelCard): Observable<TravelCard> {
    return this.http.put<TravelCard>(`${this.apiUrl}/${id}`, travelCard);
  }

  // --- DELETE ---
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  findByTraveler(travelerId: number): Observable<TravelCard[]> {
    return this.http.get<TravelCard[]>(this.apiUrl+"/bytravelerId/"+travelerId);
  }

  getMyTravelerCards(): Observable<TravelCard[]> {
    return this.http.get<TravelCard[]>(this.apiUrl+"/ofloggeduser");
  }

  createCardForUser(travelCard: TravelCard): Observable<TravelCard> {
    return this.http.post<TravelCard>(this.apiUrl+"/create/ofloggeduser", travelCard);
  }
  
}