import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../auth-service';

@Component({
  selector: 'app-main-menu',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  templateUrl: './main-menu.html',
  styleUrls: ['./main-menu.css']
})
export class MainMenu {
 
  public authService = inject(AuthService);
  private router = inject(Router);

  onLogout(): void {
    // 1. Cancella il JWT dal localStorage e azzera i Signals dello stato utente
    this.authService.logout();
    
    // 2. Reindirizza l'utente alla schermata di login di BrianzaTrains
    this.router.navigate(['/login']);
  }

}