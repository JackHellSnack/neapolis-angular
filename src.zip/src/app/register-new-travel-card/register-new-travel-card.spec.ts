import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterNewTravelCard } from './register-new-travel-card';

describe('RegisterNewTravelCard', () => {
  let component: RegisterNewTravelCard;
  let fixture: ComponentFixture<RegisterNewTravelCard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterNewTravelCard],
    }).compileComponents();

    fixture = TestBed.createComponent(RegisterNewTravelCard);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
