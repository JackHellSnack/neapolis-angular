import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import User from '../user';
import { AuthService } from '../auth-service';
import { Router } from '@angular/router';
import { TravelerCardService } from '../traveler-card-service';
import TravelCard from '../travelCard';

@Component({
  selector: 'app-register-new-travel-card',
  standalone: true,
  imports: [CommonModule, FormsModule], // Inserito qui
  templateUrl: './register-new-travel-card.html',
  styleUrls: ['./register-new-travel-card.css']
})
export class RegisterNewTravelCard {

  private travelCardService = inject(TravelerCardService);
  authService = inject(AuthService);
  private router = inject(Router);

  travelCard = signal<TravelCard>({
  duration: null as unknown as number,
  activationDate: ''
});

  issuedTravelCard = signal<TravelCard | null>(null);
  errorMessage = signal<string>('');
  successMessage = signal<string>('');

  onSubmit(): void {
    const tc = this.travelCard();

    if (!tc) {
      this.errorMessage.set("Compila tutti i campi");
      return;
    }

    const newTravelCard: TravelCard = {
      duration: this.travelCard().duration,
      activationDate: this.travelCard().activationDate
    };

      this.travelCardService.createCardForUser(newTravelCard).subscribe({
        next: (savedTravelCard) => {
          this.errorMessage.set("");
          this.successMessage.set("Saved successfully");
          this.issuedTravelCard.set(savedTravelCard);
        },
        error: (err) => {
          this.errorMessage.set('Failed to save TravelerCard. Please verify data.');
          console.error(err);
        }
      });

  }

  resetForm(): void {
    this.travelCard.set({ duration: 0, activationDate: "" });
  }
}