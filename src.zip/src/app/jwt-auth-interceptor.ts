import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from './auth-service';

/**
 * 
 * un interceptor in Angular è l'equivalente di un Filter in Spring
 * ma non si applica alle request in entrata ma a quelle in uscita 
 */
export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const token = authService.getToken();

  // Se il token esiste, cloniamo la richiesta aggiungendo l'Header Authorization
  if (token) {
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  // Passiamo la richiesta (modificata o meno) al prossimo anello della catena
  // se ho un token in authService tutte le mie request lo prenderanno automaticamente...
  return next(req);
};