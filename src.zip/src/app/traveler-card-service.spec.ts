import { TestBed } from '@angular/core/testing';

import { TravelerCardService } from './traveler-card-service';

describe('TravelerCardService', () => {
  let service: TravelerCardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelerCardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
