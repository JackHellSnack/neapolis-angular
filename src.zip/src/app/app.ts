import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MainMenu } from "./main-menu/main-menu";

@Component({
  selector: 'app-root',
  imports: [MainMenu, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('brianzatrainsfe'); 
}
