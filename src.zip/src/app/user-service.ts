import { inject, Service } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import User from './user';

@Service()
export class UserService {
  private http = inject(HttpClient);
  private apiUrl = 'http://localhost:8080/brianzatrains/api/users';

  // --- READ ALL ---
    findAll(): Observable<User[]> {
      return this.http.get<User[]>(this.apiUrl);
    }
  
    // --- READ BY ID ---
    findById(id: number): Observable<User> {
      return this.http.get<User>(`${this.apiUrl}/${id}`);
    }
  
    // --- CREATE ---
    saveAdmin(user: User): Observable<User> {
      return this.http.post<User>(this.apiUrl+"/createAdmin", user);
    }

    saveUser(user: User): Observable<User> {
      return this.http.post<User>(this.apiUrl+"/createTraveler", user);
    }
  
    // --- UPDATE ---
    update(user: User): Observable<User> {
      return this.http.put<User>(this.apiUrl, user);
    }
  
    // --- DELETE ---
    delete(id: number): Observable<void> {
      return this.http.delete<void>(`${this.apiUrl}/${id}`);
    }

    hideUser(): Observable<void> {
        return this.http.patch<void>(this.apiUrl, {});
    }

}
