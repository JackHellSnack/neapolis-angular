import { Component, OnInit, inject, signal, computed, model } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationService } from '../station-service';
import Station from '../station';

@Component({
  selector: 'app-station-picker',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './station-picker.html',
  styleUrls: ['./station-picker.css']
})
export class StationPicker implements OnInit {

  private stationService = inject(StationService);

  // Il model signal che gestisce il flusso bidirezionale con il padre
  station = model<Station | null>(null);

  // Lista completa delle stazioni caricate dal server
  private allStations = signal<Station[]>([]);
  
  // Testo inserito dall'utente nell'input di ricerca
  searchQuery = signal<string>('');
  
  // Stato per mostrare/nascondere la tendina dei suggerimenti
  showDropdown = signal<boolean>(false);

  // Signal computato: filtra automaticamente la lista in base a cosa digita l'utente
  filteredStations = computed(() => {
    const query = this.searchQuery().toLowerCase().trim();
    if (!query) {
      return [];
    }
    return this.allStations().filter(s => 
      s.name.toLowerCase().includes(query)
    );
  });

  ngOnInit(): void {
    // Carichiamo tutte le stazioni all'avvio per la ricerca locale reattiva
    this.stationService.findAll().subscribe({
      next: (data) => {
        this.allStations.set(data || []);
        // Se il padre ha preimpostato una stazione, allineiamo il testo dell'input
        const initialStation = this.station();
        if (initialStation) {
          this.searchQuery.set(initialStation.name);
        }
      },
      error: (err) => console.error('Error loading stations for picker:', err)
    });
  }

  onInputChange(value: string): void {
    this.searchQuery.set(value);
    this.showDropdown.set(value.trim().length > 0);
    
    // Se l'utente cancella o modifica il testo, svuotiamo la selezione corrente
    if (!value.trim() || (this.station() && this.station()?.name !== value)) {
      this.station.set(null);
    }
  }

  selectStation(selected: Station): void {
    this.searchQuery.set(selected.name);
    this.showDropdown.set(false);
    
    // Aggiorna il model: il componente padre riceverà istantaneamente il nuovo valore
    this.station.set(selected);
  }

  hideDropdownWithDelay(): void {
    setTimeout(() => this.showDropdown.set(false), 200);
  }
}