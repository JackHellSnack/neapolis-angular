import { Routes } from '@angular/router';
import { StationList } from './station-list/station-list';
import { authGuard } from './app-guards';
import { adminGuard } from './app-guards';
import { StationNewForm } from './station-new-form/station-new-form';
import { Login } from './login/login';
import { TicketList } from './ticket-list/ticket-list';
import { RegisterNewTicket } from './register-new-ticket/register-new-ticket';
import { NewUser } from './new-user/new-user';
import { UserProfile } from './user-profile/user-profile';
import { RegisterNewTravelCard } from './register-new-travel-card/register-new-travel-card';

export const routes: Routes = [
  // --- ROTTA DI DEFAULT (Reindirizza alla lista stazioni all'avvio) ---
  { 
    path: '', 
    redirectTo: 'login', 
    pathMatch: 'full' 
  },
  // --- ROTTE PER LE STAZIONI ---
  { 
    path: 'stations', 
    component: StationList,
    canActivate:[authGuard]
  },
  { 
    path: 'newuser', 
    component: NewUser
  },
  { 
    path: 'newtravelcard', 
    component: RegisterNewTravelCard,
    canActivate: [authGuard]
  },
  { 
    path: 'userprofile', 
    component: UserProfile,
    canActivate: [authGuard]
  },
  { 
    path: 'stations/new', 
    component: StationNewForm,
    canActivate:[adminGuard]
  },
  { 
    path: 'tickets', 
    component: TicketList,
    canActivate:[adminGuard]
  },
  { 
    path: 'tickets/buy', 
    component: RegisterNewTicket,
    canActivate:[adminGuard]
  },
  { 
    path: 'login', 
    component: Login
  }
];