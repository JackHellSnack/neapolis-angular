import { Component, input, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import Ticket from '../ticket';

@Component({
  selector: 'app-ticket-visual',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ticket-visual.html',
  styleUrls: ['./ticket-visual.css']
})
export class TicketVisual {
  // Riceve il biglietto dal componente padre tramite un input Signal di Angular
  ticket = input.required<Ticket>();

  // Computa dinamicamente l'URL del QR Code usando un'API pubblica e pulita
  qrCodeUrl = computed(() => {
    const t = this.ticket();
    const data = encodeURIComponent(`TICKET-#${t.id}|${t.departureStationName}-TO-${t.arrivalStationName}`);
    return `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${data}`;
  });
}