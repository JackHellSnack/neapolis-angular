import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketVisual } from './ticket-visual';

describe('TicketVisual', () => {
  let component: TicketVisual;
  let fixture: ComponentFixture<TicketVisual>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TicketVisual],
    }).compileComponents();

    fixture = TestBed.createComponent(TicketVisual);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
