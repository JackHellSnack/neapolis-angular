import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user-service';
import User from '../user';
import { AuthService } from '../auth-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-user',
  standalone: true,
  imports: [CommonModule, FormsModule], // Inserito qui
  templateUrl: './new-user.html',
  styleUrls: ['./new-user.css']
})
export class NewUser {

  private userService = inject(UserService);
  authService = inject(AuthService);
  private router = inject(Router);

  user = signal<User>({ email: "", username: "", password: "" });

  issuedUser = signal<User | null>(null);
  errorMessage = signal<string>('');
  successMessage = signal<string>('');
  saveA = signal<boolean>(false);

  onClickLogin(): void {
    this.router.navigate(['/login']);
  }

  onSubmit(): void {
    const usr = this.user();

    if (!usr) {
      this.errorMessage.set("Compila tutti i campi");
      return;
    }

    const newUser: User = {
      username: this.user().username,
      email: this.user().email,
      password: this.user().password
    };

    if (!this.saveA()) {
      this.userService.saveUser(newUser).subscribe({
        next: (savedUser) => {
          this.errorMessage.set("");
          this.successMessage.set("Saved successfully");
          this.issuedUser.set(savedUser);
          this.router.navigate(['/login']);
        },
        error: (err) => {
          this.errorMessage.set('Failed to save Traveler. Please verify data.');
          console.error(err);
        }
      });
    } else {
      this.userService.saveAdmin(newUser).subscribe({
        next: (savedUser) => {
          this.errorMessage.set("");
          this.successMessage.set("Saved successfully");
          this.issuedUser.set(savedUser);
          this.resetForm();
        },
        error: (err) => {
          this.errorMessage.set('Failed to save Admin. Please verify data.');
          console.error(err);
        }
      });
    }

  }

  resetForm(): void {
    this.user.set({ email: "", username: "", password: "" });
  }
}