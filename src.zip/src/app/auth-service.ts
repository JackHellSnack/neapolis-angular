import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { LoginRequestDto, LoginResponseDto, NewPasswordDto } from './auth';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private http = inject(HttpClient);
  private readonly apiUrl = 'http://localhost:8080/brianzatrains/api/auth';
  private readonly TOKEN_KEY = 'jwt_token';

  isAuthenticated = signal<boolean>(!!localStorage.getItem(this.TOKEN_KEY));
  isAdmin = signal<boolean>(this.getRoleFromToken() === 'ADMIN');

  login(credentials: LoginRequestDto): Observable<LoginResponseDto> {
    return this.http.post<LoginResponseDto>(`${this.apiUrl}/login`, credentials).pipe(
      tap(response => {
        if (response?.token) {
          localStorage.setItem(this.TOKEN_KEY, response.token);
          this.isAuthenticated.set(true);
          this.isAdmin.set(this.getRoleFromToken() === 'ADMIN');
        }
      })
    );
  }

  changePassword(newPassword: NewPasswordDto): Observable<NewPasswordDto> {
    return this.http.patch<NewPasswordDto>(this.apiUrl+"/updpwd", newPassword)
  }

  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    this.isAuthenticated.set(false);
    this.isAdmin.set(false);
  }

  getToken(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }

  // Metodo per decodificare il payload del JWT senza installare librerie esterne
  getRoleFromToken(): string | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      // Il JWT è diviso in 3 parti da punti. La seconda parte (indice 1) contiene i dati (payload)
      const payloadBase64 = token.split('.')[1];
      const decodedPayload = atob(payloadBase64); // Decodifica la stringa Base64
      const payloadObj = JSON.parse(decodedPayload);

      console.log(payloadObj);

      // Assumiamo che Spring inserisca il ruolo nel claim "role" o "roles". 
      // Al momento restituiamo un controllo base, modificalo in base a come popolerai i claims in Java
      let res = payloadObj.ROLE ? payloadObj.ROLE : payloadObj.role;

      return res;
    } catch (error) {
      return null;
    }
  }

  getInfosFromToken(): any | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      // Il JWT è diviso in 3 parti da punti. La seconda parte (indice 1) contiene i dati (payload)
      const payloadBase64 = token.split('.')[1];
      const decodedPayload = atob(payloadBase64); // Decodifica la stringa Base64
      const payloadObj = JSON.parse(decodedPayload);

      console.log(payloadObj);

   
      return payloadObj;
    } catch (error) {
      return null;
    }
  }

}
