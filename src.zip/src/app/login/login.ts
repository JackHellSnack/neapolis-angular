import { Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth-service';
import { LoginRequestDto } from '../auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html'
})
export class Login {
  // Iniezione delle dipendenze secondo gli standard di Angular moderno
  private authService = inject(AuthService);
  private router = inject(Router);

  // Modello dati associato al modulo tramite ngModel
  credentials: LoginRequestDto = {
    username: '',
    password: ''
  };

  // Stati reattivi per l'interfaccia utente gestiti con i Signals
  errorMessage = signal<string | null>(null);
  isLoading = signal<boolean>(false);

  onSubmit(): void {
    // Validazione preventiva a monte
    if (!this.credentials.username || !this.credentials.password) {
      return;
    }

    // Attivazione dello stato di caricamento e reset di vecchi errori
    this.isLoading.set(true);
    this.errorMessage.set(null);

    this.authService.login(this.credentials).subscribe({
      next: () => {
        this.isLoading.set(false);
        
        // Lettura del ruolo utente dal token per stabilire la destinazione
        const role = this.authService.getRoleFromToken();

        // Smistamento logico delle rotte in base ai privilegi dell'utente
        if (role === 'ADMIN' || role === 'ROLE_ADMIN') {
          this.router.navigate(['/stations']);
        } else {
          this.router.navigate(['/stations']);
        }
      },
      error: (err) => {
        
        console.log(err);

        this.isLoading.set(false);



        // Mappatura dell'errore HTTP restituito da Spring Security
        if (err.status === 401) {
          this.errorMessage.set('Username o password errati.');
        } else {
          this.errorMessage.set('Impossibile connettersi al server di BrianzaTrains.');
        }
      }
    });
  }
}