import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import Station from   './station';
@Injectable({
  providedIn: 'root'
})
export class StationService {

  // Utilizziamo inject() per l'iniezione delle dipendenze, in linea con lo stile moderno di Angular
  private http = inject(HttpClient);
  
  // URL del backend Spring Boot configurato nel controller
  private apiUrl = 'http://localhost:8080/brianzatrains/api/stations';

  /**
   * Recupera l'elenco di tutte le stazioni (GET)
   */
  findAll(): Observable<Station[]> {
    return this.http.get<Station[]>(this.apiUrl);
  }

  /**
   * Recupera una singola stazione tramite il suo ID (GET)
   */
  findById(id: number): Observable<Station> {
    return this.http.get<Station>(`${this.apiUrl}/${id}`);
  }

  /**
   * Salva una nuova stazione (POST)
   */
  save(station: Station): Observable<Station> {
    return this.http.post<Station>(this.apiUrl, station);
  }

  /**
   * Aggiorna una stazione esistente tramite ID (PUT)
   */
  update(id: number, station: Station): Observable<Station> {
    return this.http.put<Station>(`${this.apiUrl}/${id}`, station);
  }

  /**
   * Elimina una stazione tramite ID (DELETE)
   */
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}