import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterNewTicket } from './register-new-ticket';

describe('RegisterNewTicket', () => {
  let component: RegisterNewTicket;
  let fixture: ComponentFixture<RegisterNewTicket>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RegisterNewTicket],
    }).compileComponents();

    fixture = TestBed.createComponent(RegisterNewTicket);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
