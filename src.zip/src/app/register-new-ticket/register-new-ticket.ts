import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationPicker } from '../station-picker/station-picker';
import { TicketVisual } from '../ticket-visual/ticket-visual'; // Importiamo il nuovo componente visivo
import { TicketService } from '../ticket-service';
import Station from '../station';
import Ticket from '../ticket';

@Component({
  selector: 'app-register-new-ticket',
  standalone: true,
  imports: [CommonModule, FormsModule, StationPicker, TicketVisual], // Inserito qui
  templateUrl: './register-new-ticket.html',
  styleUrls: ['./register-new-ticket.css']
})
export class RegisterNewTicket {

  private ticketService = inject(TicketService);

  departureStation = signal<Station | null>(null);
  arrivalStation = signal<Station | null>(null);
  price = signal<number>(3);

  issuedTicket = signal<Ticket | null>(null);
  errorMessage = '';

  onSubmit(): void {
    const dep = this.departureStation();
    const arr = this.arrivalStation();

    if (!dep || !arr) {
      this.errorMessage = 'Please select both departure and arrival stations.';
      return;
    }

    if (dep.id === arr.id) {
      this.errorMessage = 'Departure and arrival stations cannot be the same.';
      return;
    }

    const newTicket: Ticket = {
      id: 0,
      price: this.price(),
      departureStationId: dep.id,
      arrivalStationId: arr.id,
      boughtOn: new Date()
    };

    this.ticketService.save(newTicket).subscribe({
      next: (savedTicket) => {
        this.errorMessage = '';
        this.issuedTicket.set(savedTicket);
      },
      error: (err) => {
        this.errorMessage = 'Failed to issue ticket. Please verify station data.';
        console.error(err);
      }
    });
  }

  resetForm(): void {
    this.departureStation.set(null);
    this.arrivalStation.set(null);
    this.price.set(3);
    this.issuedTicket.set(null);
    this.errorMessage = '';
  }
}