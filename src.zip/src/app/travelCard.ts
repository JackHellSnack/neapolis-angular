import User from "./user";

export default interface TravelCard {
  id?: number;
  travelId?: number;
  duration: number;
  activationDate: string; 
  expirationDate?: string;
  traveler?: User;
  price?: number;
  active?: boolean;
}