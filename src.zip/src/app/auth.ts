/**
 * DTO inviato dal frontend Angular durante il tentativo di login.
 * Mappa esattamente la classe Java LoginRequestDto.
 */
export interface LoginRequestDto {
  username: string;
  password: string;
}

/**
 * DTO ricevuto dal backend Spring Boot in caso di autenticazione riuscita.
 * Mappa esattamente la classe Java LoginResponseDto.
 */
export interface LoginResponseDto {
  token: string;
}

/**
 * DTO ricevuto dal backend Spring Boot in caso di autenticazione riuscita.
 * Mappa esattamente la classe Java LoginResponseDto.
 */
export interface NewPasswordDto {
  password: string;
}