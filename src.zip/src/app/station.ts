export default interface Station{
    id:number;
    name:string;
    city:string;
}