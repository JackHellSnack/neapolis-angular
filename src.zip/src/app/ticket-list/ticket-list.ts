import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TicketService } from '../ticket-service';
import Ticket from '../ticket';

@Component({
  selector: 'app-ticket-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ticket-list.html',
  styleUrls: ['./ticket-list.css']
})
export class TicketList implements OnInit {

  private ticketService = inject(TicketService);

  private allTickets = signal<Ticket[]>([]);
  searchQuery = signal<string>('');
  errorMessage = '';

  // Signal per tracciare il biglietto attualmente in fase di stampa
  selectedTicket = signal<Ticket | null>(null);

  filteredTickets = computed(() => {
    const query = this.searchQuery().toLowerCase().trim();
    if (!query) return this.allTickets();

    return this.allTickets().filter(ticket => {
      const departureName = ticket.departureStationName?.toLowerCase() || '';
      const arrivalName = ticket.arrivalStationName?.toLowerCase() || '';
      return departureName.includes(query) || arrivalName.includes(query);
    });
  });

  ngOnInit(): void {
    this.loadTickets();
  }

  loadTickets(): void {
    this.ticketService.findAll().subscribe({
      next: (data) => this.allTickets.set(data || []),
      error: (err) => {
        this.errorMessage = 'Error loading tickets from server.';
        console.error(err);
      }
    });
  }

  onPrint(ticket: Ticket): void {
    // 1. Impostiamo il biglietto selezionato nel segnale
    this.selectedTicket.set(ticket);

    // 2. Usiamo un piccolissimo delay per permettere ad Angular di renderizzare il layout di stampa nel DOM
    setTimeout(() => {
      window.print();
      // 3. Subito dopo la chiusura della finestra di stampa, resettiamo il segnale
      this.selectedTicket.set(null);
    }, 100);
  }

  onDelete(id: number): void {
    if (confirm(`Are you sure you want to delete ticket #${id}?`)) {
      this.ticketService.delete(id).subscribe({
        next: () => this.allTickets.update(tickets => tickets.filter(t => t.id !== id)),
        error: (err) => {
          this.errorMessage = `Unable to delete ticket #${id}.`;
          console.error(err);
        }
      });
    }
  }
}