import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StationService } from '../station-service';
import { AuthService } from '../auth-service';
import Station from '../station';

@Component({
  selector: 'app-station-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './station-list.html',
  styleUrls: ['./station-list.css']
})
export class StationList implements OnInit {

  private stationService = inject(StationService);
  private authService = inject(AuthService);

  // Writable signal per la gestione reattiva dello stato delle stazioni
  stations = signal<Station[]>([]);

  isAdmin = computed(
    () => this.authService.isAdmin()
  );
  
  errorMessage = signal<string>('');
  successMessage = signal<string>('');

  ngOnInit(): void {
    this.loadStations();
  }

  loadStations(): void {
    this.stationService.findAll().subscribe({
      next: (data) => {
        // Aggiorniamo il valore del signal tramite il metodo set
        this.stations.set(data || []);
      },
      error: (err) => {
        this.errorMessage.set('Error loading stations.');
        console.error(err);
      }
    });
  }

  onDelete(id: number, name: string): void {
    if (confirm(`Are you sure you want to delete the station: ${name}?`)) {
      this.stationService.delete(id).subscribe({
        next: () => {
          this.successMessage.set(`Station "${name}" deleted successfully.`);
          this.errorMessage.set('');
          // Aggiorniamo il signal filtrando l'elemento rimosso
          this.stations.update(currentStations => currentStations.filter(s => s.id !== id));
        },
        error: (err) => {
          this.errorMessage.set(`Unable to delete station "${name}".`);
          this.successMessage.set('');
          console.error(err);
        }
      });
    }
  }
}