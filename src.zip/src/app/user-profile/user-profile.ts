import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../user-service';
import User from '../user';
import { AuthService } from '../auth-service';
import { Router } from '@angular/router';
import { NewPasswordDto } from '../auth';

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule, FormsModule], // Inserito qui
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.css']
})
export class UserProfile {

  authService = inject(AuthService);

  payload = this.authService.getInfosFromToken();

  user = signal<User>({ 
    username:this.payload.sub,
    email:this.payload.EMAIL
   });

  newPassword = signal<NewPasswordDto>({password:""});

  errorMessage = signal<string>('');
  successMessage = signal<string>('');

  onSubmit(): void {

    this.authService.changePassword(this.newPassword()).subscribe({
      next: () => {
          this.successMessage.set("Updated successfully");
          this.errorMessage.set("");
          this.resetForm();
        },
        error: (err) => {
          this.successMessage.set("");
          this.errorMessage.set('Failed to update password. Please verify data.');
          console.error(err);
        }
    });

  }

  resetForm(): void {
    this.newPassword.set({ password: "" });
  }
}