export default interface Ticket {
  id: number;
  price: number;
  departureStationId: number;
  departureStationName?: string; // Opzionale perché non serve in fase di invio (POST)
  arrivalStationId: number;
  arrivalStationName?: string;   // Opzionale perché non serve in fase di invio (POST)
  boughtOn: Date | string;       // Gestisce sia l'oggetto Date nativo che la stringa ISO inviata dal server
}