import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth-service';

// DUE GUARDIE
// guardia per utente comune
// guardia per admin

/**
 * Blocca l'accesso a chiunque non sia loggato
 */
export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isAuthenticated()) {
    return true; // L'utente ha il token, può passare
  }

  // Non è autenticato: lo rispediamo al login
  router.navigate(['/login']);
  return false;
};

/**
 * Blocca l'accesso a chiunque non abbia il ruolo ADMIN
 */
export const adminGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  // Se non è nemmeno loggato, rimandalo al login
  if (!authService.isAuthenticated()) {
    router.navigate(['/login']);
    return false;
  }

  const role = authService.getRoleFromToken();
  console.log(role);

  // Controlla se il ruolo estratto dal token corrisponde ad ADMIN
  if (role === 'ADMIN' || role === 'ROLE_ADMIN') {
    console.log("Sono entrato");
    return true;
  }

  // È loggato ma non è admin: lo rimandiamo a una pagina di errore o alla home
  router.navigate(['/access-denied']);
  return false;
};